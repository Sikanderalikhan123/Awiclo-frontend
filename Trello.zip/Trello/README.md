+===================== React Vite Project Setup ===========================

Welcome to the React Vite project! To get started, follow the instructions below to install the necessary packages and run the application.

Before you begin, make sure you have the following installed on your machine:

1. Node.js: Download and install Node.js
2. npm: npm is included with Node.js, so once you install Node.js, npm will be installed automatically.

Install the project dependencies: npm install
This command installs all the required Node.js modules and packages specified in the package.json file.

To run the React app in development mode, use the following command: npm run dev
