import { GrowCardProps } from "../type";
import CustomButton from "./CustomButton";
const GrowCards = ({ data }: GrowCardProps) => {
  const { img, title, description, buttonTitle } = data;
  return (
    <div className="lg:col-span-4 md:col-span-6 col-span-12 bg-slate-50 p-6 rounded-lg">
      <img src={img} alt="" />
      <h3 className="text-xl font-semibold mt-6">{title}</h3>
      <p className="text-lg mt-2">{description}</p>
      <CustomButton title={buttonTitle} className="mt-5" />
    </div>
  );
};

export default GrowCards;
