import { Link } from "react-router-dom";
import { priceCardProps } from "../type";

const PriceCard = ({ data }: priceCardProps) => {
  return (
    <div className="ring-1 lg:col-span-3 col-span-12 ring-slate-200 bg-white p-7">
      <h5 className="text-xl font-semibold">{data.type}</h5>
      <div className="flex flex-col justify-between lg:gap-y-[90px] gap-y-5 h-full pb-12">
        <div>
          <p className="lg:mt-7 mt-4">
            $<span className="text-5xl font-semibold">{data.price}</span>USD
          </p>
          <span className="text-xs mt-4">{data.members}</span>
          <p className="text-lg font-normal mt-7">{data.description}</p>
        </div>
        <div>
          <button className="w-fit rounded-lg px-5 py-3 border-[1px] border-blue-500">
            {data.buttonTitle}
          </button>
          <Link
            to="/"
            className="underline text-blue-500 text-base font-semibold block mt-4"
          >
            {data.link}
          </Link>
        </div>
      </div>
    </div>
  );
};

export default PriceCard;
