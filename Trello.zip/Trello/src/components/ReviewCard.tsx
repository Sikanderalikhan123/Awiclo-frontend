import { ReviewCardProps } from "../type";
const ReviewCard = ({ data }: ReviewCardProps) => {
  const { img, name, title, description, link, report, read_survey } = data;
  return (
    <div className="lg:p-6 p-2">
      <div className="grid grid-cols-10 rounded-lg overflow-hidden shadow-lg">
        <div
          className="col-span-10 lg:col-span-7 lg:py-12 lg:px-10 p-5 bg-white flex flex-col justify-between self-stretch"
          style={{}}
        >
          <div className="flex justify-between flex-col h-full">
            <p className="text-2xl lg:mb-[120px] mb-10 max-w-3xl">
              {description}
            </p>
            <div>
              <p className="text-base font-medium">{name}</p>
              <p className="text-base font-medium">{title}</p>
            </div>
          </div>
          <div className="flex lg:justify-between flex-col lg:flex-row lg:items-center items-start gap-2 mt-9">
            <img src={img} alt="" className="h-9" />
            <a href="/" className="text-blue-500 underline font-medium ">
              {link}
            </a>
          </div>
        </div>
        <div className="col-span-10 lg:col-span-3 bg-gradient-to-bl from-pink-400 to-purple-500  lg:py-12 pb-14 lg:px-5 p-5 flex flex-col justify-between">
          <h3 className="sm:text-4xl text-2xl font-semibold text-white sm:leading-[45px] leading-[30px] ">
            {report}
          </h3>
          <a href="/" className="mt-14 block text-white underline">
            {read_survey}
          </a>
        </div>
      </div>
    </div>
  );
};

export default ReviewCard;
