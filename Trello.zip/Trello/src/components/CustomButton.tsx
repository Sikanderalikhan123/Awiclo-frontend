import { CustomButtonProps } from "../type";
const CustomButton = ({ title, className }: CustomButtonProps) => {
  console.log(title);
  return (
    <button
      className={`px-5 py-3 rounded-lg border-[1px] border-blue-500 text-lg font-medium ${className}`}
    >
      {title}
    </button>
  );
};

export default CustomButton;
