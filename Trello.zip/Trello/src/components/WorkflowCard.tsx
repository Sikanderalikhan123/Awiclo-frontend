import { WorkflowCardProps } from "../type";
const WorkflowCard = ({ data }: WorkflowCardProps) => {
  return (
    <div className="shadow-[rgba(13,_38,_76,_0.19)_0px_9px_20px] rounded-lg overflow-hidden relative lg:mr-9 mr-4 my-5">
      <div className={`h-10 ${data.upperLayerColor}`}></div>
      <span className="absolute top-4 left-8 z-20 bg-white p-2 rounded-lg text-red-300">
        <img src={data.img} alt="" className="h-7" />
      </span>

      <div className="p-5 pb-9">
        <h2 className="text-lg font-semibold">{data?.title}</h2>
        <p className="text-base font-normal">{data?.description}</p>
      </div>
    </div>
  );
};

export default WorkflowCard;
