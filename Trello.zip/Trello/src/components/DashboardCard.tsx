import { DasboardCardProps } from "../type";
const DashboardCard = ({ data }: DasboardCardProps) => {
  return (
    <div className="flex flex-col lg:mb-3 overflow-hidden  bg-white lg:bg-transparent rounded-lg mx-3">
      <div className="p-3 border-l-8 border-blue-500 lg:border-none">
        <h3 className="text-lg font-semibold">{data.name}</h3>
        <p className="text-base font-normal mt-3 leading-6">
          {data.description}
        </p>
      </div>
    </div>
  );
};

export default DashboardCard;
