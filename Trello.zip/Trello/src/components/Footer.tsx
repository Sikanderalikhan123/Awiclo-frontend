import Logo from "../assets/logo.svg";
import {
  FaInstagram,
  FaFacebook,
  FaLinkedin,
  FaTwitterSquare,
  FaYoutube,
} from "react-icons/fa";
import { TbWorld } from "react-icons/tb";
import { MdKeyboardArrowDown } from "react-icons/md";
import { NavLink } from "react-router-dom";
const Footer = () => {
  return (
    <footer className="bg-blue-900">
      <div className="container mx-auto grid grid-cols-10 lg:gap-2 px-16 pt-14 pb-6 text-white lg:border-b-[1px] border-slate-100">
        <div className="lg:col-span-2 col-span-10 border-b-[1px] lg:border-none py-3 border-slate-100 flex lg:flex-col justify-between items-center lg:items-start">
          <img src={Logo} alt="" className="brightness-0 invert mb-3" />
          <span>Log in</span>
        </div>

        <div className="lg:col-span-2 col-span-10 border-b-[1px] lg:border-none py-3 border-slate-100">
          <h3 className="text-sm font-semibold">About Trello</h3>
          <p className="text-xs mt-2">What’s behind the boards.</p>
        </div>
        <div className="lg:col-span-2 col-span-10 border-b-[1px] lg:border-none py-3 border-slate-100">
          <h3 className="text-sm font-semibold">Jobs</h3>
          <p className="text-xs mt-2">
            Learn about open roles on the Trello team.
          </p>
        </div>
        <div className="lg:col-span-2 col-span-10 border-b-[1px] lg:border-none py-3 border-slate-100">
          <h3 className="text-sm font-semibold">Apps</h3>
          <p className="text-xs mt-2">
            Download the Trello App for your Desktop or Mobile devices.
          </p>
        </div>
        <div className="lg:col-span-2 col-span-10 border-b-[1px] lg:border-none py-3 border-slate-100">
          <h3 className="text-sm font-semibold">Contact us</h3>
          <p className="text-xs mt-2">
            Need anything? Get in touch and we can help.
          </p>
        </div>
      </div>
      <div className="container mx-auto flex justify-between flex-col lg:flex-row lg:gap-2 gap-y-5 px-16 pt-6 pb-6 text-white ">
        <div className="flex lg:flex-row flex-col lg:items-center items-start gap-5">
          <div className="flex items-center gap-x-5">
            <div className="flex items-center gap-x-2">
              <TbWorld />
              <span>English</span>
            </div>
            <MdKeyboardArrowDown />
          </div>

          <ul className="flex flex-col lg:flex-row lg:items-center items-start gap-5">
            <li>
              <NavLink to="/">Privicy Policy</NavLink>
            </li>
            <li>
              <NavLink to="/">Terms</NavLink>
            </li>
            <li>
              <span>Copyright © 2023 Atlassian</span>
            </li>
          </ul>
        </div>
        <div className="">
          <ul className="flex items-center gap-5">
            <li>
              <span>
                <FaInstagram />
              </span>
            </li>
            <li>
              <span>
                <FaFacebook />
              </span>
            </li>{" "}
            <li>
              <span>
                <FaLinkedin />
              </span>
            </li>{" "}
            <li>
              <span>
                <FaTwitterSquare />
              </span>
            </li>{" "}
            <li>
              <span>
                <FaYoutube />
              </span>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
