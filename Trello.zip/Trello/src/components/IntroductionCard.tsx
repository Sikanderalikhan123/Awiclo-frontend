import { IntroductionCardProps } from "../type";
const IntroductionCard = ({ introData, className }: IntroductionCardProps) => {
  return (
    <div className={`max-w-[600px] ${className}`}>
      <h5 className="text-lg font-semibold">{introData?.name}</h5>
      <h3 className="text-3xl font-semibold mt-3">{introData?.title}</h3>
      <p className="font-normal text-lg mt-3 leading-6">
        {introData?.description}
      </p>
    </div>
  );
};

export default IntroductionCard;
