import { ProjectCardProps } from "../type";

const ProjectCard = ({ data, className, imgClassName }: ProjectCardProps) => {
  return (
    <div
      className={`grid grid-cols-12 gap-y-3 lg:gap-y-0  lg:gap-x-5 bg-white lg:p-8 p-5 rounded-lg shadow-[rgba(13,_38,_76,_0.19)_0px_9px_20px] ${className}`}
    >
      <img
        src={data.img}
        alt="project."
        className={`col-span-12 lg:col-span-7 ${imgClassName}`}
      />

      <div className="col-span-12 lg:col-span-5">
        <h3 className="text-lg font-semibold">{data.title}</h3>
        <p className="text-lg my-3">{data.description}</p>
        <a href="" className="text-lg text-blue-600 underline font-semibold">
          {data.link}
        </a>
      </div>
    </div>
  );
};
export default ProjectCard;
