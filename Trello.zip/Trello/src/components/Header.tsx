import { useState } from "react";
import { NavLink } from "react-router-dom";
import Logo from "../assets/logo.svg";
import { MdKeyboardArrowDown } from "react-icons/md";
import { FaBars } from "react-icons/fa";
import { AiOutlineClose } from "react-icons/ai";
const Header = () => {
  const [mobileMenu, setMobileMenu] = useState(false);
  return (
    <header className="container mx-auto p-3 lg:p-0 lg:pl-5 z-50 bg-white">
      <div className="flex justify-between lg:items-center gap-x-8">
        <div>
          <img src={Logo} alt="trello logo" />
        </div>
        <div
          className="lg:hidden flex items-center text-3xl transition-all duration-700"
          onClick={() => setMobileMenu(!mobileMenu)}
        >
          {mobileMenu ? <AiOutlineClose /> : <FaBars />}
        </div>
        <nav
          className={`${
            mobileMenu ? "right-0" : "-right-[150%]"
          } duration-300 transition-all flex flex-col lg:flex-row lg:justify-between lg:items-center w-full lg:text-base text-lg font-medium lg:static absolute mt-12 lg:mt-0 z-40 bg-white pb-7 lg:pb-0`}
        >
          <ul className="flex flex-col lg:flex-row w-full lg:w-fit lg:gap-7 text-slate-700 py-3 px-3 lg:px-0">
            <li className="flex w-full lg:w-fit justify-between items-center px-5 py-7 lg:px-0 lg:py-0 lg:border-none border-t-[1px] border-slate-200">
              <NavLink
                to="/features"
                className="cursor-pointer hover:text-blue-600 transition-all duration-300"
              >
                Features
              </NavLink>
              <MdKeyboardArrowDown classNeme="text-sm" />
            </li>
            <li className="flex w-full lg:w-fit justify-between items-center px-5 py-7 lg:px-0 lg:py-0 lg:border-none border-t-[1px] border-slate-200">
              <NavLink
                to="/solutions"
                className="cursor-pointer hover:text-blue-600 transition-all duration-300"
              >
                Solutions
              </NavLink>
              <MdKeyboardArrowDown classNeme="text-sm" />
            </li>
            <li className="flex w-full lg:w-fit justify-between items-center px-5 py-7 lg:px-0 lg:py-0 lg:border-none border-t-[1px] border-slate-200">
              <NavLink
                to="/plane"
                className="cursor-pointer hover:text-blue-600 transition-all duration-300"
              >
                Plane
              </NavLink>
              <MdKeyboardArrowDown classNeme="text-sm" />
            </li>
            <li className="flex w-full lg:w-fit justify-between items-center px-5 py-7 lg:px-0 lg:py-0 lg:border-none border-t-[1px] border-slate-200">
              <NavLink
                to="/pricing"
                className="cursor-pointer hover:text-blue-600 transition-all duration-300"
              >
                Pricing
              </NavLink>
              <MdKeyboardArrowDown classNeme="text-sm" />
            </li>
            <li className="flex w-full lg:w-fit justify-between items-center px-5 py-7 lg:px-0 lg:py-0 lg:border-none border-t-[1px] border-slate-200">
              <NavLink
                to="/resources"
                className="cursor-pointer hover:text-blue-600 transition-all duration-300"
              >
                Resources
              </NavLink>
              <MdKeyboardArrowDown classNeme="text-sm" />
            </li>
          </ul>
          <div className="flex flex-col lg:flex-row lg:items-center w-full lg:w-fit text-center gap-6 px-3 lg:px-0">
            <NavLink
              to="loge-in"
              className="w-full lg:w-fit lg:border-none border-2 border-blue-500 px-10 py-5 lg:px-0 lg:py-0"
            >
              Log In
            </NavLink>
            <h5 className="bg-blue-800 px-10 py-5 text-white w-full lg:w-fit">
              Get Trello for free
            </h5>
          </div>
        </nav>
      </div>
    </header>
  );
};

export default Header;
