import { Footer, Header } from "./components";
import { Routes, Route } from "react-router-dom";
import {
  FeaturePage,
  HomePage,
  PlanePage,
  PricingPage,
  ResourcesPage,
  SolutionsPage,
} from "./pages";

const App = () => {
  return (
    <>
      <Header />
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/feature" element={<FeaturePage />} />
        <Route path="/plane" element={<PlanePage />} />
        <Route path="/price" element={<PricingPage />} />
        <Route path="/resources" element={<ResourcesPage />} />
        <Route path="/solutions" element={<SolutionsPage />} />
      </Routes>
      <Footer />
    </>
  );
};

export default App;
