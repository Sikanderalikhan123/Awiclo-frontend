const FeaturePage = () => {
  return <div>FeaturePage</div>;
};

export default FeaturePage;
