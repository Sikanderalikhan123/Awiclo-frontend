const ResourcesPage = () => {
  return <div>ResourcesPage</div>;
};

export default ResourcesPage;
