const PricingPage = () => {
  return <div>PricingPage</div>;
};

export default PricingPage;
