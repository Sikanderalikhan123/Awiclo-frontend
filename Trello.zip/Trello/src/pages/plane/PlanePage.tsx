const PlanePage = () => {
  return <div>PlanePage</div>;
};

export default PlanePage;
