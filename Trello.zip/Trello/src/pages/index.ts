import FeaturePage from "./features/FeaturePage";
import HomePage from "./home/HomePage";
import PlanePage from "./plane/PlanePage";
import PricingPage from "./pricing/PricingPage";
import ResourcesPage from "./resources/ResourcesPage";
import SolutionsPage from "./solutions/SolutionsPage";

export {
  FeaturePage,
  HomePage,
  PlanePage,
  PricingPage,
  ResourcesPage,
  SolutionsPage,
};
