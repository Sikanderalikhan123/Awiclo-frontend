import {
  Priced,
  Projects,
  Dashboard,
  Contact,
  Reviews,
  Workflow,
  WayofGrow,
  Hero,
} from "./sections/index";
const HomePage = () => {
  return (
    <div>
      <Hero />
      <Dashboard />
      <Workflow />
      <Projects />
      <WayofGrow />
      <Reviews />
      <Priced />
      <Contact />
    </div>
  );
};

export default HomePage;
