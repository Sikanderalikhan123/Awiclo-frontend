import {
  CustomButton,
  IntroductionCard,
  ProjectCard,
} from "../../../components";

const introData = {
  title: "See work in a whole new way",
  description:
    "View your team’s projectss from every angle and bring a fresh perspective to the task at hand.",
};

const ProjectCardData = [
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/5Hb09iiMrK6mSpThW5HS89/f5683a167ad3f74bed4dc7592ae5a002/TrelloBoard_Timeline_2x.png?w=1212&fm=webp",
    title: "HIT DEADLINES EVERY TIME",
    description:
      " From weekly sprints to annual planning, Timeline view keeps all tasks on track. Quickly get a glimpse of whats coming down the pipeline and identify any gaps that might impede your teams progress.",
    link: "Learn more about Timeline view",
  },
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/5Hb09iiMrK6mSpThW5HS89/f5683a167ad3f74bed4dc7592ae5a002/TrelloBoard_Timeline_2x.png?w=1212&fm=webp",
    title: "HIT DEADLINES EVERY TIME",
    description:
      " From weekly sprints to annual planning, Timeline view keeps all tasks on track. Quickly get a glimpse of whats coming down the pipeline and identify any gaps that might impede your teams progress.",
    link: "Learn more about Timeline view",
  },
];

const Projects = () => {
  return (
    <section className="bg-project">
      <div className="container mx-auto pt-14 lg:px-14 px-5 flex flex-col items-center">
        <IntroductionCard
          introData={introData}
          className="text-white text-center"
        />
        <CustomButton
          title="Discover all Trello view"
          className="bg-white text-blue-500 mt-4"
        />

        <div className="mt-14 lg:px-14 px-1">
          {ProjectCardData.map((data, index) => {
            const isEven = index % 2 === 0;

            return (
              <ProjectCard
                data={data}
                key={index}
                className={isEven ? "" : "lg:translate-y-20 translate-y-10 "}
                imgClassName={isEven ? "" : "lg:order-1"}
              />
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Projects;
