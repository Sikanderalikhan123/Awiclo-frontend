import { useEffect, useState } from "react";
import Slider, { Settings } from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { dashboardCardData } from "../../../constent/data";
import { DashboardCard, IntroductionCard } from "../../../components";

const introData = {
  name: "TRELLO 101",
  title: "A productivity powerhouse",
  description:
    "Simple, flexible, and powerful. All it takes are boards, lists, and cards to get a clear view of whos doing what and what needs to get done. Learn more in our guide for getting started.",
};

const Dashboard = () => {
  const [nav1, setNav1] = useState<Slider | null>(null);
  const [nav2, setNav2] = useState<Slider | null>(null);

  const setting1: Settings = {
    dots: true,
    asNavFor: nav2 || undefined,
    slidesToShow: 3,
    vertical: true,
    infinite: false,
    focusOnSelect: true,
    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          vertical: false,
        },
      },
    ],
  };

  const setting2: Settings = {
    asNavFor: nav1 || undefined,
    slidesToShow: 1,
    infinite: false,
    focusOnSelect: true,
  };

  let slider1: Slider | null, slider2: Slider | null;

  useEffect(() => {
    if (slider1) setNav1(slider1);
    if (slider2) setNav2(slider2);
  }, []);

  return (
    <section className="bg-gradient-to-t from-sky-100 to-white">
      <div className="container mx-auto lg:p-14 p-5 flex flex-col">
        <IntroductionCard introData={introData} />
        <div className="grid grid-cols-10 mx-auto mt-7 gap-y-5 lg:gap-y-0 lg:gap-x-5 power">
          <div className="lg:col-span-3 col-span-12 flex flex-col power-house gap-5">
            <Slider {...setting1} ref={(slider) => (slider1 = slider)}>
              {dashboardCardData.map((data, index) => (
                <DashboardCard data={data} key={index} />
              ))}
            </Slider>
          </div>
          <div className="lg:col-span-7 col-span-10 order-first lg:order-2">
            <Slider ref={(slider) => (slider2 = slider)} {...setting2}>
              {dashboardCardData.map((data, index) => (
                <img src={data.img} alt="" className="px-3" key={index} />
              ))}
            </Slider>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Dashboard;
