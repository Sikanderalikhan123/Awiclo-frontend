import { MdOutlineSlowMotionVideo } from "react-icons/md";
export const Hero = () => {
  return (
    <>
      <section className=" relative bg-gradient-to-r from-purple-500 to-pink-500">
        <main className="container mx-auto pt-[90px]">
          <div className="flex flex-col lg:flex-row items-center lg:justify-between gap-5">
            <div className="lg:w-1/2 w-full flex flex-col lg:items-start items-center lg:text-start text-center text-white px-14">
              <h1 className="text-3xl md:text-5xl lg:text-5xl font-semibold">
                Trello brings all your tasks, teammates, and tools together
              </h1>
              <p className="font-medium text-lg mt-5">
                Keep everything in the same place—even if your team isn’t.
              </p>
              <div className="mt-5 flex gap-2 flex-col lg:flex-row  w-full">
                <input
                  type="text"
                  className="px-3 py-3 border-none outline-none rounded-lg w-full max-w-[300px] hidden lg:inline-block text-slate-700"
                  placeholder="Email"
                />
                <button className="w-full lg:w-fit px-5 py-3 bg-blue-500 rounded-lg whitespace-nowrap">
                  Sign-up - it's free!
                </button>
              </div>
              <div className="flex items-center gap-3 mt-5 text-2xl">
                <span className="text-lg">Watch video</span>
                <MdOutlineSlowMotionVideo />
              </div>
            </div>
            <div className="lg:w-1/2 w-full flex justify-center lg:justify-end relative z-10">
              <img
                src="https://images.ctfassets.net/rz1oowkt5gyp/75rDABL8fyMtNLlUAtBxrg/c5e145977a86c41c47e17c69410c64f7/TrelloUICollage_4x.png?w=540"
                alt=""
                className="w-full max-w-[90%]"
              />
            </div>
          </div>
          <div className="custom-shape-divider-bottom-1700646882">
            <svg
              data-name="Layer 1"
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 1200 120"
              preserveAspectRatio="none"
            >
              <path
                d="M321.39,56.44c58-10.79,114.16-30.13,172-41.86,82.39-16.72,168.19-17.73,250.45-.39C823.78,31,906.67,72,985.66,92.83c70.05,18.48,146.53,26.09,214.34,3V0H0V27.35A600.21,600.21,0,0,0,321.39,56.44Z"
                className="shape-fill"
              ></path>
            </svg>
          </div>
        </main>
      </section>
    </>
  );
};
