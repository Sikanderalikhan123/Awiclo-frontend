import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { reviewCardData } from "../../../constent/data";
import { ReviewCard } from "../../../components";

const WayofGrow = () => {
  const settings = {
    dots: true,
    className: "center",
    infinite: false,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    initialSlide: 0,
  };
  return (
    <section className="py-[90px] bg-gradient-to-t from-sky-100 to-white">
      <div className="container mx-auto lg:px-[70px] px-5 work-flow-card">
        <Slider {...settings}>
          {reviewCardData.map((data, index) => (
            <ReviewCard data={data} key={index} />
          ))}
        </Slider>
      </div>
    </section>
  );
};

export default WayofGrow;
