import { GrowCards, IntroductionCard } from "../../../components";
import { growCardData } from "../../../constent/data";

const introData = {
  name: "POWERFUL WAYS TO GROW",
  title: "Do more with Trello",
  description:
    " Trello’s intuitive features give any team the ability to quickly set up and customize workflows for just about anything.",
};

const Reviews = () => {
  return (
    <section className="mt-[200px]">
      <div className="container mx-auto px-5 pb-9">
        <div>
          <IntroductionCard introData={introData} />
        </div>
        <div className="grid grid-cols-12 gap-5 mt-8">
          {growCardData.map((date, index) => (
            <GrowCards data={date} key={index} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Reviews;
