import { Hero } from "./Hero";
import Priced from "./Priced";
import Projects from "./Project";
import Dashboard from "./Dashboard";
import Contact from "./Contact";
import Reviews from "./Reviews";
import Workflow from "./Workflow";
import WayofGrow from "./WayofGrow";

export {
  Hero,
  Priced,
  Projects,
  Dashboard,
  Contact,
  Reviews,
  Workflow,
  WayofGrow,
};
