import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { workflowCardData } from "../../../constent/data";
import { IntroductionCard, WorkflowCard } from "../../../components";

const introData = {
  name: "TRELLO IN ACTION",
  title: "Workflows for any project, big or small",
};
const Workflow = () => {
  const settings = {
    className: "center",
    infinite: false,
    speed: 500,
    slidesToShow: 3,
    slidesToScroll: 3,
    initialSlide: 0,

    responsive: [
      {
        breakpoint: 1024,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1,
        },
      },
    ],
  };

  return (
    <section>
      <div className="container mx-auto px-5 py-[90px]">
        <IntroductionCard introData={introData} />
        <div className="my-[80px] work-flow px-3">
          <Slider {...settings}>
            {workflowCardData.map((data, index) => (
              <WorkflowCard key={index} data={data} />
            ))}
          </Slider>
        </div>

        <div className="flex justify-between flex-col lg:flex-row items-start lg:items-center gap-5 mt-14">
          <p className="max-w-[750px] text-lg font-semibold">
            No need to start from scratch. Jump-start your workflow with a
            proven playbook designed for different teams. Customize it to make
            it yours.
          </p>
          <button className="px-5 py-3 rounded-lg border-[1px] border-blue-500">
            Explore all Use Cases
          </button>
        </div>
      </div>
    </section>
  );
};

export default Workflow;
