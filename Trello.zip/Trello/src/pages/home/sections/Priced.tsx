import { CustomButton, IntroductionCard, PriceCard } from "../../../components";
import { priceCardData } from "../../../constent/data";

const Priced = () => {
  const introData = {
    title: "Trello priced your way",
    description:
      "Trusted by millions, Trello powers teams all around the world.",
  };
  return (
    <section className="bg-gradient-to-t to-sky-100 from-white">
      <div className="container mx-auto flex flex-col items-center py-9 px-5">
        <IntroductionCard introData={introData} className="text-center" />
        <CustomButton
          title="Compare plans"
          className="text-white bg-blue-500 mt-4"
        />
        <div className="mt-14 grid grid-cols-12 gap-y-5 lg:px-14 px-6">
          {priceCardData.map((data, index) => (
            <PriceCard data={data} key={index} />
          ))}
        </div>
        <div className="mt-[90px] px-5">
          <p className="text-lg font-semibold text-center mb-6">
            Join over 2,000,000 teams worldwide that are using Trello to get
            more done.
          </p>
          <img
            src="https://images.ctfassets.net/rz1oowkt5gyp/19rAABnbk8KNNuh3zJzsmr/210fb8ee51dea14595462f844b7c9beb/logos-horizontal-visa-coinbase-john-deere-zoom-grand-hyatt-fender.svg"
            alt=""
            className="flex flex-wrap"
          />
        </div>
      </div>
    </section>
  );
};

export default Priced;
