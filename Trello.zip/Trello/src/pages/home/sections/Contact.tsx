const Contact = () => {
  return (
    <section className="bg-contact">
      <div className="container mx-auto lg:px-16 px-5 py-[90px]">
        <h2 className="text-center text-2xl font-semibold text-white">
          Get Started with Trello Today
        </h2>
        <div className="mt-5 flex flex-col md:flex-row gap-2 justify-center">
          <input
            type="text"
            className="px-3 py-2 border-none outline-none rounded-lg w-full max-w-[420px] hidden md:inline-block"
            placeholder="Email"
          />
          <button className="w-full md:w-fit px-5 py-3 bg-blue-500 rounded-lg sm:whitespace-nowrap text-white">
            Sign-up - it's free!
          </button>
        </div>
      </div>
    </section>
  );
};

export default Contact;
