const SolutionsPage = () => {
  return <div>SolutionsPage</div>;
};

export default SolutionsPage;
