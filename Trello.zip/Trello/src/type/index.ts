type GrowCard = {
  img: string;
  title: string;
  description: string;
  buttonTitle: string;
};

type ReviewCard = {
  img: string;
  name: string;
  title: string;
  description: string;
  link: string;
  report: string;
  read_survey: string;
};

type WorkflowCard = {
  img: string;
  title: string;
  description: string;
  upperLayerColor: string;
};

type DashboardCard = {
  name: string;
  description: string;
  img: string;
};

type PriceCard = {
  type: string;
  price: string;
  members: string;
  description: string;
  buttonTitle: string;
  link?: string;
};

export type { GrowCard, ReviewCard, WorkflowCard, DashboardCard, PriceCard };

//************ interfaces for Different componenets ************

interface CustomButtonProps {
  title: string;
  className: string;
}

interface DasboardCardProps {
  data: {
    name: string;
    description: string;
  };
}

interface GrowCardProps {
  data: {
    img: string;
    title: string;
    description: string;
    buttonTitle: string;
  };
}

interface IntroductionCardProps {
  introData: {
    name?: string;
    title: string;
    description?: string;
  };
  className?: string;
}

interface ReviewCardProps {
  data: {
    name: string;
    title: string;
    description: string;
    img: string;
    link: string;
    report: string;
    read_survey: string;
  };
}

interface WorkflowCardProps {
  data: {
    upperLayerColor: string;
    img: string;
    title: string;
    description: string;
  };
}

interface ProjectCardProps {
  data: {
    img: string;
    title: string;
    description: string;
    link: string;
  };
  className?: string;
  imgClassName?: string;
}
interface priceCardProps {
  data: {
    type: string;
    price: string;
    members: string;
    description: string;
    buttonTitle: string;
    link?: string;
  };
}
export type {
  CustomButtonProps,
  DasboardCardProps,
  ReviewCardProps,
  WorkflowCardProps,
  IntroductionCardProps,
  GrowCardProps,
  ProjectCardProps,
  priceCardProps,
};
