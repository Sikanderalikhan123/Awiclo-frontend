import {
  DashboardCard,
  GrowCard,
  PriceCard,
  ReviewCard,
  WorkflowCard,
} from "../type";

export const growCardData: GrowCard[] = [
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/gMfkjoA3yWYG3kat3qjpW/3902bfdfccf08869e33d63bbc9d1969b/Integrations_Puzzle.svg",
    title: "Integrations",
    description:
      "Connect the apps your team already uses into your Trello workflow or add a Power-Up to fine-tune your specific needs.",
    buttonTitle: "Browse Integrations",
  },
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/7wxRW93hvb7858bMsK4LSs/f6fc44fb23dbc6ee9bc6a7f6e2af0fb7/Gears.svg",
    title: "Butler Automation",
    description:
      "No-code automation is built into every Trello board. Focus on the work that matters most and let the robots do the rest.",
    buttonTitle: "Get to know Atomations",
  },
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/mNa3Mi7T6ga2OTrNxJx1D/8991b8d57cd6ec7330398c7a8757b4dc/Search_Value.svg",
    title: "Trello Enterprise",
    description:
      "The productivity tool teams love, paired with the features and security needed for scale.",
    buttonTitle: "Explore Interprise",
  },
];

export const reviewCardData: ReviewCard[] = [
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/2f3keSvy7vtldV4YDFKkE2/5ed788fb5257c342995d25ba8e8e313d/WomenWhoCode_logo.svg",
    name: "Joey Rosenberg",
    title: "Global Leadership Director at Women Who Code",
    description:
      "[Trello is] great for simplifying complex processes. As a manager, I can chunk [processes] down into bite-sized pieces for my team and then delegate that out, but still keep a bird's-eye view.",
    link: "Read the story",
    report:
      "75% of organizations report that Trello delivers value to their business within 30 days.",
    read_survey: "Trello TechValidate Survey",
  },
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/2f3keSvy7vtldV4YDFKkE2/5ed788fb5257c342995d25ba8e8e313d/WomenWhoCode_logo.svg",
    name: "Joey Rosenberg",
    title: "Global Leadership Director at Women Who Code",
    description:
      "[Trello is] great for simplifying complex processes. As a manager, I can chunk [processes] down into bite-sized pieces for my team and then delegate that out, but still keep a bird's-eye view.",
    link: "Read the story",
    report:
      "75% of organizations report that Trello delivers value to their business within 30 days.",
    read_survey: "Trello TechValidate Survey",
  },
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/2f3keSvy7vtldV4YDFKkE2/5ed788fb5257c342995d25ba8e8e313d/WomenWhoCode_logo.svg",
    name: "Joey Rosenberg",
    title: "Global Leadership Director at Women Who Code",
    description:
      "[Trello is] great for simplifying complex processes. As a manager, I can chunk [processes] down into bite-sized pieces for my team and then delegate that out, but still keep a bird's-eye view.",
    link: "Read the story",
    report:
      "75% of organizations report that Trello delivers value to their business within 30 days.",
    read_survey: "Trello TechValidate Survey",
  },
];

export const workflowCardData: WorkflowCard[] = [
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/5Oc1c9iIDmXtUFHs0uWuLQ/cef21b3212ac080d9d0adad649dc31e9/icon-content-folder_2x.png",
    title: "Project management",
    description:
      "Onboarding to a new company or project is a snap with Trello’s visual layout of to-do’s, resources, and progress tracking.",
    upperLayerColor: "bg-red-300",
  },
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/5JwPiAFuOJCWEdYiTqlfs3/ca86f7f918d09a1782284ba4578a28ec/icon-object-leaf_2x.png",
    title: "Meetings",
    description:
      "Onboarding to a new company or project is a snap with Trello’s visual layout of to-do’s, resources, and progress tracking.",
    upperLayerColor: "bg-green-200",
  },
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/5j0J5BEzFktzLYnsszcJWc/be9270f9ea1e9bb3c69a799e54ef9fea/icon-object-megaphone_2x.png",
    title: "Onboarding",
    description:
      "Onboarding to a new company or project is a snap with Trello’s visual layout of to-do’s, resources, and progress tracking.",
    upperLayerColor: "bg-blue-300",
  },
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/4Mgm4SG6P6bD673rMtNpXP/9f8798510480b30d296550be747b9624/icon-content-checklists_2x.png",
    title: "Task management",
    description:
      "Onboarding to a new company or project is a snap with Trello’s visual layout of to-do’s, resources, and progress tracking.",
    upperLayerColor: "bg-yellow-300",
  },
  {
    img: "https://images.ctfassets.net/rz1oowkt5gyp/5JwPiAFuOJCWEdYiTqlfs3/ca86f7f918d09a1782284ba4578a28ec/icon-object-leaf_2x.png",
    title: "Brainstorming",
    description:
      "Onboarding to a new company or project is a snap with Trello’s visual layout of to-do’s, resources, and progress tracking.",
    upperLayerColor: "bg-pink-300",
  },
];

export const dashboardCardData: DashboardCard[] = [
  {
    name: "Boards",
    description:
      "Trello boards keep tasks organized and work moving forward. In a glance, see everything from “things to do” to “aww yeah, we did it!”",
    img: "https://images.ctfassets.net/rz1oowkt5gyp/3N2U3C71rApm61cGFxnc2E/970b010002488a09a420282df5e7b43a/Carousel_Image_Boards_2x.png?w=1140&fm=webp",
  },
  {
    name: "Lists",
    description:
      "Trello boards keep tasks organized and work moving forward. In a glance, see everything from “things to do” to “aww yeah, we did it!”",
    img: "https://images.ctfassets.net/rz1oowkt5gyp/4U0VUZYX2tQmB5KVGxBabp/7321ac088fe8ec39dbe3069c47d7df99/Carousel_Image_Lists_2x.png?w=540",
  },
  {
    name: "Cards",
    description:
      "Trello boards keep tasks organized and work moving forward. In a glance, see everything from “things to do” to “aww yeah, we did it!”",
    img: "https://images.ctfassets.net/rz1oowkt5gyp/26CA6JZeRgoOK4nuRHnIlY/060702a80cf7c3be3651d9297d196267/Carousel_Image_Cards_2x.png?w=1140&fm=webp",
  },
];

export const priceCardData: PriceCard[] = [
  {
    type: "Free",
    price: "0",
    members: "Free for your whole team",
    description: "For individuals or teams looking to organize any project.",
    buttonTitle: "Get Started",
  },
  {
    type: "STANDARD",
    price: "5",
    members: "Per user/month if billed annually ($6 billed monthly)",
    description:
      "For small teams that need to manage work and scale collaboration.",
    buttonTitle: "Sign up now",
    link: "Learn more about Standard",
  },
  {
    type: "PREMIUM",
    price: "10",
    members: "Per user/month if billed annually ($12.50 billed monthly)",
    description:
      "For teams that need to track and visualize multiple projects in several ways, including boards, timelines, calendars, etc.",
    buttonTitle: "Try for free",
    link: "Learn more about Premium",
  },
  {
    type: "ENTERPRISE",
    price: "17.50",
    members: "Per user/month - billed annually ($210.00 annual price per user)",
    description:
      "For organizations that need to connect work across teams with more security and controls.",
    buttonTitle: "Contact sales",
    link: "Learn more about Enterprise",
  },
];
